import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Mostra os tipos de notificação

        System.out.println("Escolha o tipo de notificação:");
        System.out.println("1: Email");
        System.out.println("2: SMS");
        System.out.println("3: Push Notification");

        // Captura a opção escolhida pelo usuário
        int choice = scanner.nextInt();
        scanner.nextLine();  // Faz a leitura da nova linha após o número

        // Solicita a mensagem
        System.out.print("Digite a mensagem a ser enviada: ");
        String message = scanner.nextLine();

        // Converte a opção para uma string correspondente
        String notificationType = null;
        switch (choice) {
            case 1:
                notificationType = "email";
                break;
            case 2:
                notificationType = "sms";
                break;
            case 3:
                notificationType = "push";
                break;
            default:
                System.out.println("Opção inválida.");
                System.exit(0);
        }

        // Cria a notificação usando o factory e envia a mensagem
        Notification notification = NotificationFactory.createNotification(notificationType);
        if (notification != null) {
            notification.send(message);
        }
    }
}
