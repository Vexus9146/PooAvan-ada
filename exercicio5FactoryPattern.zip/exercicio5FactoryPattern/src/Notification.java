public interface Notification {
// Define o metodo a ser implementado pelas outras classes
// as outras classes Email Sms e push usam esse metodo de seu modo unico
    void send(String message);
}
