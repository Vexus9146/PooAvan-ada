public class NotificationFactory {
// implementa a criação das notificações para o usuario escolher o tipo de formato que deseja a notificação
    public static Notification createNotification(String type) {
        if (type == null) {
            return null;
        }
        switch (type.toLowerCase()) {
            case "email":
                return new EmailNotification();
            case "sms":
                return new SmsNotification();
            case "push":
                return new PushNotification();
            default:
                System.out.println("Tipo de notificação inválido.");
                return null;

        }

    }
}
