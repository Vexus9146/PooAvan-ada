import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Exibe as opções de pagamento
        System.out.println("Escolha o método de pagamento:");
        System.out.println("1: Pix");
        System.out.println("2: Cartão de Crédito");
        System.out.println("3: Boleto");

        // Captura a opção escolhida pelo usuário
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consome a nova linha após o número

        // Solicita o valor da transação
        System.out.print("Digite o valor da transação: R$");
        double amount = scanner.nextDouble();

        // Converte a opção para uma string correspondente
        String paymentType = null;
        switch (choice) {
            case 1:
                paymentType = "pix";
                break;
            case 2:
                paymentType = "cartao de credito";
                break;
            case 3:
                paymentType = "boleto";
                break;
            default:
                System.out.println("Opção inválida.");
                System.exit(0);
        }

        // Cria a estratégia de pagamento via Factory
        PaymentStrategy paymentStrategy = PaymentFactory.createPayment(paymentType);

        if (paymentStrategy != null) {
            // Processa o pagamento
            PaymentProcessor processor = new PaymentProcessor(paymentStrategy);
            processor.process(amount);
        }
    }
}
