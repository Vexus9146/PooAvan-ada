public class BoletoPayment implements PaymentStrategy {

    @Override
    public void processPayment(double amount) {
        String boletoCode = "BOLETO-" + System.currentTimeMillis();
        System.out.println("Pagamento via Boleto aprovado!");
        System.out.println("Código do boleto: " + boletoCode);
        System.out.println("Valor: R$" + amount);
    }
}
