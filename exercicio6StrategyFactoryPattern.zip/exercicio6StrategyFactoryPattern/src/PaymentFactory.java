public class PaymentFactory {
    public static PaymentStrategy createPayment(String type) {
        if (type == null) {
            return null;
        }
        switch (type.toLowerCase()) {
            case "pix":
                return new PixPayment();
            case "cartao de credito":
                return new CreditCardPayment();
            case "boleto":
                return new BoletoPayment();
            default:
                System.out.println("Tipo de pagamento inválido.");
                return null;
        }
    }
}
