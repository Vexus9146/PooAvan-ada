import java.util.Random;

public class PixPayment implements PaymentStrategy {

    @Override
    public void processPayment(double amount) {
        Random random = new Random();
        String pixCode = "PIX-" + random.nextInt(1000000);
        System.out.println("Pagamento via Pix aprovado!");
        System.out.println("Código Pix: " + pixCode);
        System.out.println("Valor: R$" + amount);
    }
}
