package org.example;

import entities.User;
import repository.UserRepository;
import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserRepository userRepository = new UserRepository();

        while (true) {
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Cadastrar usuário");
            System.out.println("2 - Listar usuários");
            System.out.println("3 - Sair");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar o buffer

            switch (opcao) {
                case 1:
                    System.out.print("Nome: ");
                    String name = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Senha: ");
                    String password = scanner.nextLine();

                    User user = new User(name, email, password);
                    userRepository.save(user);
                    System.out.println("Usuário cadastrado com sucesso!");
                    break;
                case 2:
                    List<User> users = userRepository.findAll();
                    for (User u : users) {
                        System.out.println("UUID: " + u.getUuid());
                        System.out.println("Nome: " + u.getName());
                        System.out.println("Email: " + u.getEmail());
                        System.out.println("Senha: " + u.getPassword());
                        System.out.println();
                    }
                    break;
                case 3:
                    System.out.println("Saindo...");
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}
